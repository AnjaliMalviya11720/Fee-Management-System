/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package fees_management_system;

import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author ashis
 */
public class SignUp_page extends javax.swing.JFrame {

    /**
     * Creates new form SignUp_page
     */
    public SignUp_page() {
        initComponents();
    }
    
     String firstname , lastname,username , email,contact,password,conPassword;
    boolean validation(){
        
       
        
        firstname = fname.getText();
        lastname = lname.getText();
        username = uname.getText();
        email = emailid.getText();
        contact = cnumber.getText();
        conPassword = cpassword.getText();
        password = pass.getText();
        
        if(firstname.equals("")){
           JOptionPane.showMessageDialog(this,"Please enter the Firstname");
           return false;
        }
        
         if(lastname.equals("")){
           JOptionPane.showMessageDialog(this,"Please enter the lastname");
           return false;
        }
         
          if(username.equals("")){
           JOptionPane.showMessageDialog(this,"Please enter the username");
           return false;
        }
           if(email.equals("")){
           JOptionPane.showMessageDialog(this,"Please enter the email ID");
           return false;
        }
           
            if(contact.equals("")){
           JOptionPane.showMessageDialog(this,"Please enter the Contact no.");
           return false;
        }
             if(password.equals("")){
           JOptionPane.showMessageDialog(this,"Please enter the password ");
           return false;
        }
             
              if(conPassword.equals("")){
           JOptionPane.showMessageDialog(this,"Please enter the confirm Password ");
           return false;
        }
            
         if(!password.equals(conPassword)) {
             JOptionPane.showMessageDialog(this, "password  is not same ");
         }    
          
                
        
        return true;
    }
    
      public void checkContactlength(){
         contact = cnumber.getText();
        if(contact.length() == 10){
            lbl_contact_error.setText(" ");
        }
        else{
                  lbl_contact_error.setText("Contact should of 10 digits");
        }
    }

    public void checkPasswordError(){
        password = pass.getText();
        if(password.length()<8){
            lbl_password_error.setText("Password should of 8 characters");
        }
        else{
            lbl_password_error.setText("");
        }
    }
    
    
  
     void insertData() throws ClassNotFoundException{
         try {
             Class.forName("com.mysql.cj.jdbc.Driver");
             Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fee_management","root","");
             
             // First check if username already exists
             String checkSql = "SELECT * FROM signup WHERE uname = ?";
             PreparedStatement checkStmt = con.prepareStatement(checkSql);
             checkStmt.setString(1, username);
             ResultSet rs = checkStmt.executeQuery();
             
             if(rs.next()) {
                 JOptionPane.showMessageDialog(this, "Username already exists. Please choose a different username.");
                 return;
             }
             
             String sql = "INSERT INTO signup(fname,lname,uname,password) VALUES(?,?,?,?)";
             PreparedStatement stmt = con.prepareStatement(sql);
             stmt.setString(1, firstname);
             stmt.setString(2, lastname);
             stmt.setString(3, username);
             stmt.setString(4, password);
             
             int i = stmt.executeUpdate();
             
             if(i > 0) {
                 JOptionPane.showMessageDialog(this, "Registration successful!");
                 login_page login = new login_page();
                 login.setVisible(true);
                 this.dispose();
             } else {
                 JOptionPane.showMessageDialog(this, "Registration failed. Please try again.");
             }
             
             rs.close();
             checkStmt.close();
             stmt.close();
             con.close();
             
         } catch (SQLException ex) {
             Logger.getLogger(SignUp_page.class.getName()).log(Level.SEVERE, null, ex);
             JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
         }
     }
 
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        fname = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        lname = new javax.swing.JTextField();
        uname = new javax.swing.JTextField();
        emailid = new javax.swing.JTextField();
        cnumber = new javax.swing.JTextField();
        pass = new javax.swing.JPasswordField();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        cpassword = new javax.swing.JPasswordField();
        jLabel8 = new javax.swing.JLabel();
        backbtn = new javax.swing.JButton();
        signb = new javax.swing.JButton();
        lbl_contact_error = new javax.swing.JLabel();
        lbl_password_error = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        lbl_ = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 204, 204));
        jLabel2.setText("First Name          : ");
        jLabel2.setVerifyInputWhenFocusTarget(false);
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, 170, -1));

        fname.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        fname.addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                fnameComponentAdded(evt);
            }
        });
        getContentPane().add(fname, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 220, 250, 30));

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 204, 204));
        jLabel4.setText("Last name           : ");
        jLabel4.setVerifyInputWhenFocusTarget(false);
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 270, 190, -1));

        lname.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lnameActionPerformed(evt);
            }
        });
        getContentPane().add(lname, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 270, 250, 30));

        uname.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        getContentPane().add(uname, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 320, 250, 30));

        emailid.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        emailid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailidActionPerformed(evt);
            }
        });
        getContentPane().add(emailid, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 370, 250, 32));

        cnumber.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        cnumber.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cnumberKeyReleased(evt);
            }
        });
        getContentPane().add(cnumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 420, 250, 30));

        pass.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        pass.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                passKeyReleased(evt);
            }
        });
        getContentPane().add(pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 470, 250, -1));

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 204, 204));
        jLabel7.setText("UserName           :");
        jLabel7.setVerifyInputWhenFocusTarget(false);
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 330, 154, -1));

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 204, 204));
        jLabel6.setText("Email ID             :");
        jLabel6.setVerifyInputWhenFocusTarget(false);
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 370, 154, 30));

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 204, 204));
        jLabel5.setText("Contact Number   : ");
        jLabel5.setVerifyInputWhenFocusTarget(false);
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 420, 160, -1));

        jLabel9.setBackground(new java.awt.Color(0, 0, 0));
        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 204, 204));
        jLabel9.setText("Password            : ");
        jLabel9.setVerifyInputWhenFocusTarget(false);
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 470, 197, -1));

        cpassword.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        getContentPane().add(cpassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 520, 250, -1));

        jLabel8.setBackground(new java.awt.Color(0, 0, 0));
        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 204, 204));
        jLabel8.setText("Confirm Password : ");
        jLabel8.setVerifyInputWhenFocusTarget(false);
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 520, 197, -1));

        backbtn.setFont(new java.awt.Font("Montserrat", 1, 18)); // NOI18N
        backbtn.setText(" BACK");
        backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbtnActionPerformed(evt);
            }
        });
        getContentPane().add(backbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 640, 100, 43));

        signb.setFont(new java.awt.Font("Montserrat", 1, 18)); // NOI18N
        signb.setText("SIGN UP");
        signb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signbActionPerformed(evt);
            }
        });
        getContentPane().add(signb, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 600, 138, 43));

        lbl_contact_error.setBackground(new java.awt.Color(255, 0, 0));
        lbl_contact_error.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbl_contact_error.setForeground(new java.awt.Color(204, 0, 0));
        getContentPane().add(lbl_contact_error, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 410, 250, 50));

        lbl_password_error.setBackground(new java.awt.Color(255, 0, 0));
        lbl_password_error.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbl_password_error.setForeground(new java.awt.Color(255, 0, 0));
        getContentPane().add(lbl_password_error, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 460, 240, 30));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Sign Up");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 90, -1, -1));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 160, 220, 10));

        lbl_.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fees_management_system/flat-lay-workstation-with-copy-space-laptop.jpg"))); // NOI18N
        lbl_.setText("6");
        getContentPane().add(lbl_, new org.netbeans.lib.awtextra.AbsoluteConstraints(-140, -60, 1850, 970));
        lbl_.getAccessibleContext().setAccessibleName("777777777777777");

        setSize(new java.awt.Dimension(1313, 715));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void backbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbtnActionPerformed
        login_page login = new login_page();
        login.show();
        this.dispose();
    }//GEN-LAST:event_backbtnActionPerformed

    private void signbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signbActionPerformed

        if(validation()){
            try {
                insertData();

            } catch (ClassNotFoundException ex) {
                Logger.getLogger(SignUp_page.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }//GEN-LAST:event_signbActionPerformed

    private void passKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_passKeyReleased
        checkPasswordError();
    }//GEN-LAST:event_passKeyReleased

    private void cnumberKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cnumberKeyReleased
        checkContactlength();
    }//GEN-LAST:event_cnumberKeyReleased

    private void emailidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailidActionPerformed

    }//GEN-LAST:event_emailidActionPerformed

    private void lnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lnameActionPerformed

    private void fnameComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_fnameComponentAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_fnameComponentAdded

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SignUp_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SignUp_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SignUp_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SignUp_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SignUp_page().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backbtn;
    private javax.swing.JTextField cnumber;
    private javax.swing.JPasswordField cpassword;
    private javax.swing.JTextField emailid;
    private javax.swing.JTextField fname;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lbl_;
    private javax.swing.JLabel lbl_contact_error;
    private javax.swing.JLabel lbl_password_error;
    private javax.swing.JTextField lname;
    private javax.swing.JPasswordField pass;
    private javax.swing.JButton signb;
    private javax.swing.JTextField uname;
    // End of variables declaration//GEN-END:variables
}
